A help desk system that manages ticket submission and assignment.
